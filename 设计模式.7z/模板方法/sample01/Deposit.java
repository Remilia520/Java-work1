public class Deposit extends BankTemplateMethod
{
	public void transact()
	{
		System.out.println("���");		
	}
}