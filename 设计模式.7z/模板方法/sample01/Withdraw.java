public class Withdraw extends BankTemplateMethod
{
	public void transact()
	{
		System.out.println("ȡ��");		
	}
}