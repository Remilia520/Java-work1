public interface Node
{
	public int interpret();
}