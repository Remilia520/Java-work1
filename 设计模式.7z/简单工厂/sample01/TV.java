public interface TV
{
	public void play();
}