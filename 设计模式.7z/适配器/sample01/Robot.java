public interface Robot
{
	public void cry();
	public void move();
}