public interface Color
{
	void bepaint(String penType,String name);
}