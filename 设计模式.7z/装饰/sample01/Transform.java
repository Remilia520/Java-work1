public interface Transform
{
	public void move();
}